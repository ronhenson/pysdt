from pydantic import BaseModel

# write a Food pydantic model